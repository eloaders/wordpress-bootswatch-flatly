<div class="container">
      <div class="col-md-4 col-sm-4">
        <?php dynamic_sidebar( 'Hero Widget One' ); ?>
      </div>
      <div class="col-md-4 col-sm-4">
        <?php dynamic_sidebar( 'Hero Widget Two' ); ?>
      </div>
      <div class="col-md-4 col-sm-4">
        <?php dynamic_sidebar( 'Hero Widget Thre' ); ?>
      </div>
</div>
